package second;

import java.util.Scanner;

public class no03 {
    public static void main(String[] args) {
        System.out.println("5개의 숫자를 입력");
        Scanner a = new Scanner(System.in);
        int[] b = a.nextInt();


        for (int i = 0; i < 5; i++) {
           b[] = sc.nextInt();
        }
        System.out.println("오름차순으로 정렬해줄게");

    }
}
